# main.py (na raiz do projeto)
import uvicorn
from app.main import app # Importa a instância app de app.main

if __name__ == "__main__":
    # host="0.0.0.0" para permitir acesso externo se necessário
    # reload=True é útil para desenvolvimento
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)