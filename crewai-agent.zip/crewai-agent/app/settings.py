# app/settings.py
from pydantic_settings import BaseSettings
from typing import List, Optional

class ApiSettings(BaseSettings):
    title: str = "CrewAI Meta-Arquitetos API"
    version: str = "0.1.0"
    docs_enabled: bool = True
    # Lista de origens permitidas para CORS. Para desenvolvimento, ["*"] é comum.
    # Em produção, restrinja para seus domínios front-end.
    cors_origin_list: List[str] = ["*"] # Exemplo: ["http://localhost:3000", "https://seufrontend.com"]
    bearer_token: Optional[str] = None # Será carregado do .env

    class Config:
        env_file = ".env" # Nome do arquivo .env na raiz do projeto
        env_file_encoding = 'utf-8'
        extra = 'ignore' # Ignora variáveis de ambiente extras que não estão no modelo

api_settings = ApiSettings()