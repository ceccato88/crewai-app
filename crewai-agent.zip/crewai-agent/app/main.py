# app/main.py
import sys
import os
from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from starlette.middleware.cors import CORSMiddleware
from app.routes.v1_router import v1_router
from app.settings import api_settings # Importa as configurações

# Adiciona o diretório raiz do projeto ao sys.path
# para que 'crew.meta_architect_crew' possa ser encontrado.
# Se app/main.py está em /project_root/app/main.py,
# então o diretório raiz é um nível acima de 'app'.
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Carregar variáveis de ambiente (isso é feito implicitamente pelo Pydantic BaseSettings
# se `env_file` estiver configurado, mas pode ser explícito se necessário antes)
from dotenv import load_dotenv
dotenv_path = os.path.join(PROJECT_ROOT, '.env') # Garante que o .env da raiz seja lido
if os.path.exists(dotenv_path):
    load_dotenv(dotenv_path=dotenv_path)
else:
    print(f"Aviso: Arquivo .env não encontrado em {dotenv_path}. Certifique-se de que BEARER_TOKEN está definido no ambiente.")


security = HTTPBearer()

# BEARER_TOKEN é carregado em api_settings ou diretamente do os.getenv
# Vamos usar o de api_settings para consistência, que já lê do .env
# BEARER_TOKEN = os.getenv("BEARER_TOKEN")
# if not BEARER_TOKEN:
#     print("AVISO CRÍTICO: BEARER_TOKEN não está configurado no ambiente ou .env. A autenticação da API falhará.")
    # Em um cenário real, você pode querer lançar um erro aqui se o token for essencial para iniciar.
    # raise EnvironmentError("BEARER_TOKEN não encontrado. A API não pode iniciar com segurança.")


def verify_token(authorization: HTTPAuthorizationCredentials = Depends(security)):
    # Acessa o token das configurações carregadas do .env
    expected_token = api_settings.bearer_token
    if not expected_token: # Verifica se o token foi carregado
        print("ERRO DE CONFIGURAÇÃO: BEARER_TOKEN não foi carregado nas configurações da API.")
        raise HTTPException(status_code=500, detail="Erro de configuração do servidor: token de autenticação não definido.")

    if authorization.credentials != expected_token:
        raise HTTPException(status_code=403, detail="Token inválido ou expirado")
    return authorization.credentials

def create_app() -> FastAPI:
    app_instance: FastAPI = FastAPI(
        title=api_settings.title,
        version=api_settings.version,
        docs_url="/docs" if api_settings.docs_enabled else None,
        redoc_url="/redoc" if api_settings.docs_enabled else None,
        openapi_url="/openapi.json" if api_settings.docs_enabled else None,
    )

    # Inclui o roteador v1, aplicando a dependência de verificação de token a todas as suas rotas
    app_instance.include_router(v1_router, dependencies=[Depends(verify_token)])

    app_instance.add_middleware(
        CORSMiddleware,
        allow_origins=api_settings.cors_origin_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    return app_instance

app = create_app()