# app/routes/agents.py
from fastapi import APIRouter, HTTPException, Body, BackgroundTasks
from pydantic import BaseModel, Field
from crew.meta_architect_crew.main import run_meta_crew # ATUALIZADO o import

class CreateMetaCrewRequest(BaseModel):
    user_initial_request: str = Field(..., 
                                      min_length=10,
                                      example="Preciso de uma equipe CrewAI para analisar o sentimento de notícias sobre IA e gerar relatórios semanais em formato JSON.")

agents_router = APIRouter()

# Para tarefas de longa duração, é melhor usar BackgroundTasks do FastAPI
# A função `run_meta_crew` é síncrona por natureza e pode ser longa.
# Uma solução mais robusta envolveria Celery ou similar, mas BackgroundTasks é um começo.

@agents_router.post("/create_meta_crew/", 
                    summary="Dispara a Meta-Equipe para projetar e gerar uma nova aplicação CrewAI",
                    status_code=202) # Accepted, pois a tarefa pode demorar
async def create_meta_crew_endpoint(
    background_tasks: BackgroundTasks,
    request_body: CreateMetaCrewRequest = Body(...)
):
    """
    Recebe uma solicitação do usuário descrevendo a equipe CrewAI que ele deseja criar.
    A Meta-Equipe de Arquitetos irá processar esta solicitação e gerar:
    - Documentos de design (DER, DDAT, EFI)
    - Código Python para a equipe solicitada, seguindo a estrutura FastAPI modelo
    - Um relatório final de documentação
    - Um sumário dos testes de código executados (se aplicável)

    Todos os artefatos serão salvos em um subdiretório dentro de `generated_crews/`.
    Esta rota retorna imediatamente uma mensagem de aceitação, e o processamento
    ocorre em segundo plano. O resultado final (caminho dos arquivos) será logado no servidor.
    """
    try:
        inputs = {"user_initial_request": request_body.user_initial_request}

        # Adiciona a tarefa demorada ao background
        # A função `run_meta_crew` precisa ser adaptada se quisermos um callback ou notificação
        # Por enquanto, ela apenas executa e loga no console do servidor.
        # background_tasks.add_task(run_meta_crew, inputs)

        # Para uma resposta imediata e demonstração, vamos executar sincronamente
        # mas com aviso de que isso bloqueará a thread da API.
        # Em produção, a abordagem com background_tasks.add_task(run_meta_crew, inputs) seria melhor,
        # mas exigiria uma forma de notificar o usuário sobre a conclusão (ex: webhook, email, status polling).

        print(f"INFO: Recebida solicitação para Meta-Equipe: {request_body.user_initial_request[:50]}...")
        # Execução síncrona para este exemplo, para retornar o resultado direto.
        # Considere refatorar para background task em produção.
        result_message_from_crew = run_meta_crew(inputs)

        print(f"INFO: Meta-Equipe concluiu para: {request_body.user_initial_request[:50]}. Resultado no console.")

        return {
            "status": "processing_initiated", # ou "success" se síncrono
            "message": "Meta-Equipe iniciou o processamento da sua solicitação. Os resultados e arquivos gerados estarão disponíveis no diretório 'generated_crews/' no servidor.",
            "result_summary_from_meta_crew": result_message_from_crew 
        }

    except HTTPException as http_exc: # Re-lança HTTPExceptions
        raise http_exc
    except Exception as e:
        print(f"ERRO CRÍTICO ao processar create_meta_crew: {type(e).__name__} - {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Erro interno do servidor ao processar com a Meta-Equipe: {str(e)}")