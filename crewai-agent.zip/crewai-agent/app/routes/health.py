# app/routes/health.py
from fastapi import APIRouter

health_router = APIRouter()

@health_router.get("/health", summary="Verifica a saúde da API")
def get_health():
    """
    Endpoint simples para verificar se a API está operacional.
    """
    return {"status": "ok"}