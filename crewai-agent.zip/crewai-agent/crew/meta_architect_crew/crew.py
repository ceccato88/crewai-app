# crew/meta_architect_crew/crew.py
from crewai import Crew, Process
from crew.meta_architect_crew.meta_agents import (
    acsc_agent, arcu_agent, edc_agent, efi_agent, gvcc_agent, cdp_agent
)
from crew.meta_architect_crew.meta_tasks import (
    task_acsc_planning,
    task_arcu_requirements_analysis,
    task_edc_design_agents_tasks,
    task_efi_specify_tools,
    task_gvcc_generate_and_test_code,
    task_cdp_document_solution,
    task_acsc_final_review
)
from crew.meta_architect_crew.config import manager_llm_config, embedding_model, FASTAPI_PROJECT_STRUCTURE_TEMPLATE

class MetaArchitectsCrew:
    def __init__(self):
        self.agents_list = [
            acsc_agent, arcu_agent, edc_agent, efi_agent, gvcc_agent, cdp_agent
        ]
        self.tasks_list = [
            task_acsc_planning,
            task_arcu_requirements_analysis,
            task_edc_design_agents_tasks,
            task_efi_specify_tools,
            task_gvcc_generate_and_test_code,
            task_cdp_document_solution,
            task_acsc_final_review
        ]

    def get_crew(self) -> Crew:
        return Crew(
            agents=self.agents_list,
            tasks=self.tasks_list,
            process=Process.hierarchical,
            manager_agent=acsc_agent,
            manager_llm=manager_llm_config,
            memory=True,
            cache=True,
            verbose=2,
            planning=True,
            planning_llm=manager_llm_config,
            embedder={
                "provider": "openai",
                "config": {"model": embedding_model}
            }
        )