# crew/meta_architect_crew/meta_tasks.py
from crewai import Task
from crew.meta_architect_crew.meta_agents import (
    acsc_agent, arcu_agent, edc_agent, efi_agent, gvcc_agent, cdp_agent
)
from crew.meta_architect_crew.config import KNOWLEDGE_MDX_URL_RAW, FASTAPI_PROJECT_STRUCTURE_TEMPLATE

# Tarefa de Planejamento Inicial para o ACSC
task_acsc_planning = Task(
    description=(
        "Analisar a solicitação do usuário para uma nova aplicação CrewAI ('{user_initial_request}'). "
        f"Considerar que a base de conhecimento específica sobre 'Knowledge/Memory' do CrewAI está acessível online via RAG na URL '{KNOWLEDGE_MDX_URL_RAW}' através da ferramenta `knowledge_mdx_retriever_tool`. "
        "Desenvolver um plano de projeto detalhado para a Meta-Equipe. Este plano deve: "
        "1. Identificar fases do projeto. 2. Atribuir responsabilidades aos especialistas. "
        "3. Definir entregáveis e critérios de aceitação. 4. Estabelecer pontos de verificação/revisão. "
        "5. Delinear como os documentos de referência CrewAI (incluindo o `knowledge_mdx_retriever_tool` para '{KNOWLEDGE_MDX_URL_RAW}') serão aplicados. "
        "O plano deve ser o roteiro completo e acionável."
    ),
    expected_output=(
        "Um documento de 'Plano de Projeto Estratégico' em formato Markdown. "
        "Contendo: Sumário da Solicitação, Fases, Matriz de Responsabilidades, Cronograma Estimado, Estratégia de Aplicação dos Documentos CrewAI (incluindo `knowledge_mdx_retriever_tool` para '{KNOWLEDGE_MDX_URL_RAW}'), Pontos de Controle."
    ),
    agent=acsc_agent
)

# Tarefa de Análise de Requisitos para o ARCU
task_arcu_requirements_analysis = Task(
    description=(
        "Com base no 'Plano de Projeto Estratégico' e na solicitação ('{user_initial_request}'), "
        "conduzir análise de requisitos. Use `FileReadTool` para arquivos, `website_scraper_tool` para URLs genéricas. "
        f"Para K/M, consulte ATIVAMENTE '{KNOWLEDGE_MDX_URL_RAW}' usando `knowledge_mdx_retriever_tool`. "
        "Utilizar 'Evaluating Use Cases for CrewAI' e 'Processes' para classificar o problema, justificar arquitetura e processo. "
        "Produzir um DER detalhado. Use `file_writer_tool` para salvar o DER. Argumentos para FileWriterTool: "
        "filename='DER.md', content='[conteúdo completo do DER em Markdown]', directory='{results_dirname}'."
    ),
    expected_output=(
        "Confirmação do salvamento de 'DER.md' no diretório '{results_dirname}'. O DER (conteúdo do arquivo) deve conter: "
        "1. Reinterpretação da Solicitação. 2. Requisitos Funcionais. 3. Requisitos Não Funcionais. "
        "4. Análise 'Complexidade vs. Precisão'. 5. Recomendação de Macroarquitetura/Processo. "
        "6. Escopo. 7. Critérios de Aceitação. 8. (Se aplicável) Análise de '{KNOWLEDGE_MDX_URL_RAW}' para K/M."
    ),
    agent=arcu_agent,
    context=[task_acsc_planning]
)

# Tarefa de Design de Agentes e Tarefas para o EDC
task_edc_design_agents_tasks = Task(
    description=(
        "Utilizando o DER (lido de '{results_dirname}/DER.md' com `file_read_tool`) como base, projetar a arquitetura detalhada dos agentes e tarefas. "
        "Definir RGB, expertise, ferramentas, etc., conforme 'Crafting Effective Agents'. "
        f"Para K/M, consulte OBRIGATORIAMENTE '{KNOWLEDGE_MDX_URL_RAW}' usando `knowledge_mdx_retriever_tool`. "
        "Produzir um DDAT. Use `file_writer_tool` para salvar. Argumentos para FileWriterTool: "
        "filename='DDAT.md', content='[conteúdo completo do DDAT em Markdown]', directory='{results_dirname}'."
    ),
    expected_output=(
        "Confirmação do salvamento de 'DDAT.md' no diretório '{results_dirname}'. O DDAT (conteúdo do arquivo) deve conter: "
        "1. Visão Geral. 2. Definição de Agentes (RGB, expertise, tools, LLM, K/M design baseado em '{KNOWLEDGE_MDX_URL_RAW}'). "
        "3. Definição de Tarefas. 4. Configurações da Crew. 5. Justificativa de Design."
    ),
    agent=edc_agent,
    context=[task_arcu_requirements_analysis]
)

# Tarefa de Especificação de Ferramentas para o EFI
task_efi_specify_tools = Task(
    description=(
        "Analisar o DDAT (lido de '{results_dirname}/DDAT.md' com `file_read_tool`). "
        "Pesquisar e especificar ferramentas CrewAI/LangChain/customizadas. "
        "Detalhar configuração, uso, APIs, e especificações para ferramentas customizadas. "
        "Produzir uma EFI. Use `file_writer_tool` para salvar. Argumentos para FileWriterTool: "
        "filename='EFI.md', content='[conteúdo completo da EFI em Markdown]', directory='{results_dirname}'."
    ),
    expected_output=(
        "Confirmação do salvamento de 'EFI.md' no diretório '{results_dirname}'. O EFI (conteúdo do arquivo) deve conter: "
        "1. Introdução. 2. Ferramentas por Agente (Nome, Descrição, Fonte, Configuração, Exemplo, Especificação se customizada). 3. Dependências Globais."
    ),
    agent=efi_agent,
    context=[task_edc_design_agents_tasks]
)

# Tarefa de Geração e Validação de Código para o GVCC
task_gvcc_generate_and_test_code = Task(
    description=(
        "Com base no DDAT (de `{results_dirname}/DDAT.md`) e EFI (de `{results_dirname}/EFI.md`) - usar `file_read_tool` para lê-los - "
        "gerar o código Python completo para a aplicação CrewAI solicitada pelo usuário. "
        "O código gerado DEVE SER EMBUTIDO NA SEGUINTE ESTRUTURA DE PROJETO FastAPI:\n"
        f"{FASTAPI_PROJECT_STRUCTURE_TEMPLATE}\n" # Injeta o template da estrutura aqui
        "Para cada arquivo na estrutura acima, gere o conteúdo apropriado. Salve CADA ARQUIVO GERADO na estrutura de diretórios correta dentro de `{results_dirname}/codigo_gerado/` usando a `FileWriterTool`. "
        "Por exemplo, para salvar `app/main.py`, os argumentos para FileWriterTool seriam: "
        "filename='main.py', content='[conteúdo python de app/main.py]', directory='{results_dirname}/codigo_gerado/app/'. "
        "Para o `main.py` da raiz: filename='main.py', content='[conteúdo python do main.py raiz]', directory='{results_dirname}/codigo_gerado/'. "
        "E assim por diante para todos os arquivos da estrutura, incluindo `__init__.py` (podem ser vazios ou com imports), `requirements.txt`, `.env.example`, `pyproject.toml`. "
        "Utilizar `allow_code_execution` para validar sintaxe e executar snippets de teste da *nova crew gerada*. "
        "O sumário dos testes deve ser salvo em `{results_dirname}/codigo_gerado/test_execution_summary.md` usando a `FileWriterTool`."
    ),
    expected_output=(
        "Confirmação de que todos os arquivos da estrutura FastAPI foram gerados e salvos em `{results_dirname}/codigo_gerado/`. "
        "O pacote deve incluir: "
        "1. Estrutura de diretórios FastAPI completa com todos os arquivos .py e __init__.py. "
        "2. `requirements.txt` para a nova aplicação. "
        "3. `.env.example` para a nova aplicação. "
        "4. `pyproject.toml` para a nova aplicação. "
        "5. `test_execution_summary.md` com os resultados dos testes."
    ),
    agent=gvcc_agent,
    context=[task_edc_design_agents_tasks, task_efi_specify_tools],
    max_retries=2
)

# Tarefa de Documentação da Solução para o CDP
task_cdp_document_solution = Task(
    description=(
        "Revisar TODOS os artefatos: DER (de `{results_dirname}/DER.md`), DDAT (de `{results_dirname}/DDAT.md`), EFI (de `{results_dirname}/EFI.md`), "
        "Código Fonte (de `{results_dirname}/codigo_gerado/`) e `test_execution_summary.md`. Usar `file_read_tool`. "
        "Consolidar em um Relatório Final. "
        "O relatório DEVE justificar CADA escolha de design com referências explícitas aos documentos CrewAI, e especificamente ao conteúdo de '{KNOWLEDGE_MDX_URL_RAW}' "
        "(consultado via `knowledge_mdx_retriever_tool`) ao discutir K/M. "
        "Explicar como o código gerado se encaixa na estrutura FastAPI. "
        "Incluir resultados dos testes, snippets de código chave, instruções de configuração/execução. Discutir manutenção/extensibilidade. "
        "Salvar o relatório final usando `file_writer_tool`. Argumentos para FileWriterTool: "
        "filename='RelatorioFinalMetaCrew.md', content='[conteúdo completo do relatório em Markdown]', directory='{results_dirname}'."
    ),
    expected_output=(
        "Confirmação do salvamento de 'RelatorioFinalMetaCrew.md' no diretório '{results_dirname}'. "
        "O Relatório Final (conteúdo do arquivo) deve ser único, abrangente... justificando como os conceitos de '{KNOWLEDGE_MDX_URL_RAW}' e a estrutura FastAPI foram aplicados."
    ),
    agent=cdp_agent,
    context=[
        task_arcu_requirements_analysis,
        task_edc_design_agents_tasks,
        task_efi_specify_tools,
        task_gvcc_generate_and_test_code
    ]
)

# Tarefa de Revisão Final para o ACSC
task_acsc_final_review = Task(
    description=(
        "Realizar uma revisão executiva de todos os entregáveis no diretório `{results_dirname}` (Relatório Final, Pacote de Código FastAPI). "
        "Verificar: Qualidade, completude, alinhamento com a solicitação ('{user_initial_request}'), conformidade com padrões CrewAI (incluindo uso do '{KNOWLEDGE_MDX_URL_RAW}' e da estrutura FastAPI), clareza da documentação, e robustez. "
        "Preparar uma nota de capa (string) resumindo o conteúdo do pacote no diretório `{results_dirname}`."
    ),
    expected_output=(
        "Uma mensagem de confirmação final indicando que o pacote de entrega está completo, revisado e pronto. "
        "A mensagem deve listar os principais arquivos e o caminho do diretório de resultados '{results_dirname}'. "
        "Incluir quaisquer observações finais críticas."
    ),
    agent=acsc_agent,
    context=[task_cdp_document_solution, task_gvcc_generate_and_test_code]
)