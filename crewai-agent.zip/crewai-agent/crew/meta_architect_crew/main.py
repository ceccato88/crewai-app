# crew/meta_architect_crew/main.py
import os
import datetime
from crew.meta_architect_crew.crew import MetaArchitectsCrew
from crew.meta_architect_crew.config import KNOWLEDGE_MDX_URL_RAW, FASTAPI_PROJECT_STRUCTURE_TEMPLATE # Importa o template

def run_meta_crew(inputs: dict):
    print("🚀 Executando a Meta-Equipe de Arquitetos CrewAI...")
    print(f"Solicitação do Usuário: {inputs.get('user_initial_request')[:100]}...")

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    user_request_slug = inputs.get('user_initial_request', 'generic_request')
    request_slug_safe = "".join(c if c.isalnum() else "_" for c in user_request_slug[:40]).strip('_')
    if not request_slug_safe:
        request_slug_safe = "unnamed_request"

    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    results_dirname_abs = os.path.join(project_root, "generated_crews", f"crew_{request_slug_safe}_{timestamp}")
    results_dirname_for_tasks = os.path.join("generated_crews", f"crew_{request_slug_safe}_{timestamp}") # Relativo ao root do projeto

    if not os.path.exists(results_dirname_abs):
        os.makedirs(results_dirname_abs)
        # Cria também o subdiretório para o código gerado
        os.makedirs(os.path.join(results_dirname_abs, "codigo_gerado"), exist_ok=True)

    print(f"Diretório de resultados para esta execução: {results_dirname_abs}")

    extended_inputs = {
        **inputs,
        'results_dirname': results_dirname_for_tasks, # Usado nas tasks para construir paths
        'KNOWLEDGE_MDX_URL_RAW': KNOWLEDGE_MDX_URL_RAW,
        'FASTAPI_PROJECT_STRUCTURE_TEMPLATE': FASTAPI_PROJECT_STRUCTURE_TEMPLATE # Injeta o template
    }

    meta_crew_instance = MetaArchitectsCrew().get_crew()
    result = meta_crew_instance.kickoff(inputs=extended_inputs)

    print("\n✅ Execução da Meta-Equipe concluída.")
    return result