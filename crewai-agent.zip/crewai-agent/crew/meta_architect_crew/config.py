# crew/meta_architect_crew/config.py
import os
from langchain_openai import ChatOpenAI
from crewai_tools import (
    SerperDevTool,
    WebsiteSearchTool,
    FileReadTool,
    CodeDocsSearchTool,
    FileWriterTool
)

# --- Constantes ---
KNOWLEDGE_MDX_URL_RAW = "https://raw.githubusercontent.com/ceccato88/crewai-api/blob/main/knowledge.mdx"

# Template da Estrutura do Projeto FastAPI para o GVCC (EXATAMENTE COMO VOCÊ FORNECEU)
FASTAPI_PROJECT_STRUCTURE_TEMPLATE = """
Modelo de Equipe de agentes + FAST Api
.
├── app
│   ├── main.py
│   ├── routes
│   │   ├── agents.py
│   │   ├── health.py
│   │   └── v1_router.py
│   └── settings.py
├── crew
│   └── research_crew  # Este nome '{crew_name}' será substituído dinamicamente
│       ├── agents.yaml
│       ├── crew.py
│       ├── main.py
│       └── tasks.yaml
├── main.py
├── pyproject.toml
├── requirements.txt

# main.py (Raiz do Projeto Gerado)
import uvicorn
from app.main import app

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
	
#app/main.py (Para o Projeto Gerado)
import sys
import os
from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from starlette.middleware.cors import CORSMiddleware
# O nome do router importado aqui dependerá do {crew_name}
# from app.routes.v1_router import v1_router # Este será o v1_router do projeto gerado
# from app.settings import api_settings # Este será o settings.py do projeto gerado

# Exemplo de como o GVCC deve adaptar o sys.path se necessário:
# Se a estrutura 'src' for usada pela crew gerada, algo como:
# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'crew', '{crew_name}')))
# Mas para a estrutura fornecida, o import da crew será mais direto.

# Estas importações precisam ser adaptadas pelo GVCC para o contexto do projeto GERADO:
from app.routes.v1_router import v1_router # Assume que está correto para o projeto gerado
from app.settings import api_settings       # Assume que está correto para o projeto gerado


security = HTTPBearer()

BEARER_TOKEN = os.getenv("BEARER_TOKEN_GENERATED_APP", "default_generated_app_token") # Usar um nome diferente para o token da app gerada

def verify_token(authorization: HTTPAuthorizationCredentials = Depends(security)):
    if authorization.credentials != BEARER_TOKEN:
        raise HTTPException(status_code=403, detail="Token inválido ou expirado para a aplicação gerada")
    return authorization.credentials

def create_app() -> FastAPI:
    app_instance: FastAPI = FastAPI(
        title=api_settings.title, # Virá do settings.py gerado
        version=api_settings.version, # Virá do settings.py gerado
        docs_url="/docs" if api_settings.docs_enabled else None,
        redoc_url="/redoc" if api_settings.docs_enabled else None,
        openapi_url="/openapi.json" if api_settings.docs_enabled else None,
    )
    app_instance.include_router(v1_router, dependencies=[Depends(verify_token)])
    app_instance.add_middleware(
        CORSMiddleware,
        allow_origins=api_settings.cors_origin_list,  
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    return app_instance

app = create_app()


# app/routes/agents.py (Para o Projeto Gerado)
from fastapi import APIRouter, HTTPException, Body
from pydantic import BaseModel, Field
from crew.{crew_name}.main import run as run_generated_crew # O GVCC precisa substituir {crew_name}

class GeneratedCrewRequest(BaseModel):
    # Os inputs aqui dependerão da crew que o usuário solicitou à Meta-Equipe
    # O GVCC precisará definir este modelo Pydantic dinamicamente ou usar um genérico
    # Exemplo genérico:
    user_input: str = Field(..., example="Dados para a equipe processar")
    # Ou, se a crew gerada sempre espera um 'topic', como no exemplo research_crew:
    # topic: str

agents_router = APIRouter() # Nome genérico, o GVCC pode manter ou adaptar

# O GVCC deve definir o nome da rota e o nome da função de forma apropriada
@agents_router.post("/run_generated_crew/") 
async def handle_run_generated_crew(request: GeneratedCrewRequest = Body(...)):  
    try:
        # O GVCC precisa garantir que os inputs corretos sejam passados para run_generated_crew
        # Exemplo: se run_generated_crew espera {'topic': 'algo'}
        # inputs_for_crew = {"topic": request.topic} 
        # Se for genérico:
        inputs_for_crew = request.model_dump() # Passa todos os campos do request
        result = run_generated_crew(inputs_for_crew)
        return {"status": "success", "message": "Equipe gerada executada com sucesso!", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao executar equipe gerada: {{str(e)}}")
		
# app/routes/health.py (Para o Projeto Gerado)
from fastapi import APIRouter

health_router = APIRouter()

@health_router.get("/health")
def get_health():
    return {"status": "ok"} # Simples status "ok"
	
# app/routes/v1_router.py (Para o Projeto Gerado)
from fastapi import APIRouter
from app.routes.health import health_router
from app.routes.agents import agents_router # Importa o agents_router do projeto gerado

v1_router = APIRouter(prefix="/v1")

v1_router.include_router(health_router, prefix="/system", tags=["System Health"]) # Ajuste de prefixo/tags
v1_router.include_router(agents_router, prefix="/crew", tags=["Generated Crew Actions"]) # Ajuste de prefixo/tags

# O GVCC NÃO DEVE GERAR ARQUIVOS YAML PARA AGENTES E TAREFAS,
# pois foi instruído a criar definições diretamente em Python para a nova equipe.
# As seções abaixo (agents.yaml, crew.py exemplo, tasks.yaml) são parte do SEU EXEMPLO
# e o GVCC deve usá-los como INSPIRAÇÃO para a estrutura Python em
# crew/{crew_name}/agents.py, crew/{crew_name}/tasks.py, crew/{crew_name}/crew.py.

# INÍCIO DO EXEMPLO DE CONTEÚDO PARA crew/{crew_name} (GVCC DEVE ADAPTAR PARA PYTHON)

# Exemplo de como seria crew/{crew_name}/agents.py (GVCC gera o conteúdo real)
# from crewai import Agent
# from crewai_tools import AlgumaFerramenta
# def define_agente_X(...):
#     return Agent(...)

# Exemplo de como seria crew/{crew_name}/tasks.py (GVCC gera o conteúdo real)
# from crewai import Task
# def define_tarefa_Y(...):
#     return Task(...)

# Exemplo de como seria crew/{crew_name}/crew.py (GVCC gera o conteúdo real)
# from crewai import Crew, Process
# from .agents import AgenteX, AgenteY # Imports relativos
# from .tasks import Tarefa1, Tarefa2
# class NomeDaNovaCrew:
#     def __init__(self):
#         self.agentes = [AgenteX, AgenteY] # Instâncias dos agentes
#         self.tarefas = [Tarefa1, Tarefa2] # Instâncias das tarefas
#     def get_crew(self):
#         return Crew(agents=self.agentes, tasks=self.tarefas, process=Process.sequential)

# Exemplo de como seria crew/{crew_name}/main.py (GVCC gera o conteúdo real)
# from .crew import NomeDaNovaCrew # Import relativo
# def run(inputs: dict):
#     crew_instance = NomeDaNovaCrew().get_crew()
#     result = crew_instance.kickoff(inputs)
#     return result

# FIM DO EXEMPLO DE CONTEÚDO PARA crew/{crew_name}
"""

# --- Configuração dos LLMs ---
# (O restante do seu config.py permanece o mesmo daqui para baixo)
manager_llm_model = os.getenv("OPENAI_MODEL_NAME_MANAGER", "gpt-4o")
code_llm_model = os.getenv("OPENAI_MODEL_NAME_CODE", "gpt-4o")
agent_llm_model = os.getenv("OPENAI_MODEL_NAME_AGENT", "gpt-4o-mini")
embedding_model = os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")

manager_llm_config = ChatOpenAI(model=manager_llm_model, temperature=0.2)
llm_for_code_execution = ChatOpenAI(model=code_llm_model, temperature=0.1)
agent_llm_config = ChatOpenAI(model=agent_llm_model, temperature=0.7)

# --- Ferramentas ---
serper_tool = SerperDevTool()
website_scraper_tool = WebsiteSearchTool(
    name="Generic Website Scraper",
    description="Uma ferramenta para buscar e extrair o conteúdo textual principal de qualquer página da web fornecendo sua URL."
)
file_read_tool = FileReadTool()
code_docs_tool = CodeDocsSearchTool()
file_writer_tool = FileWriterTool()

knowledge_mdx_retriever_tool = WebsiteSearchTool(
    website_url=KNOWLEDGE_MDX_URL_RAW,
    name="CrewAI Knowledge Base Retriever (MDX via URL)",
    description=f"Uma ferramenta RAG especializada para buscar e responder perguntas semanticamente com base no conteúdo do documento CrewAI sobre Knowledge e Memory, localizado em '{KNOWLEDGE_MDX_URL_RAW}'.",
    config=dict(
        llm=dict(
            provider="openai",
            config=dict(model=agent_llm_model),
        ),
        embedder=dict(
            provider="openai",
            config=dict(model=embedding_model),
        ),
    )
)